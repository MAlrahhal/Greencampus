GreenCampus synthetic academic demonstration data. Not real university records.
Coverage: 2025-01-01 through 2025-12-31, hourly, 30 meters = 262800 readings.
10 buildings, 5 departments, 200 collection requests and 200 collection records, 40 hazardous approvals.
Values are synthetic and illustrative; import and anomaly detection require application implementation and tests.
